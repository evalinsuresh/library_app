from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
import os

app = Flask(__name__)
app.secret_key = "library_secret_key"

# Configure SQLite database (persistent)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///library.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# ---------- Database Model ----------
class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    author = db.Column(db.String(200), nullable=False)
    available = db.Column(db.Boolean, default=True, nullable=False)

    def __repr__(self):
        return f"<Book {self.title}>"

# ---------- Routes ----------
@app.route('/')
def index():
    books = Book.query.all()
    return render_template('index.html', books=books)

@app.route('/add', methods=['POST'])
def add():
    title = request.form['title'].strip()
    author = request.form['author'].strip()

    if not title or not author:
        flash("Please fill in both Title and Author fields.", "error")
        return redirect(url_for('index'))

    new_book = Book(title=title, author=author)
    db.session.add(new_book)
    db.session.commit()
    flash(f"Book '{title}' added successfully!", "success")
    return redirect(url_for('index'))

@app.route('/borrow/<int:book_id>', methods=['POST'])
def borrow(book_id):
    book = Book.query.get_or_404(book_id)
    if not book.available:
        flash(f"'{book.title}' is already borrowed.", "error")
    else:
        book.available = False
        db.session.commit()
        flash(f"You borrowed '{book.title}'.", "success")
    return redirect(url_for('index'))

@app.route('/return/<int:book_id>', methods=['POST'])
def return_book(book_id):
    book = Book.query.get_or_404(book_id)
    if book.available:
        flash(f"'{book.title}' is already available.", "info")
    else:
        book.available = True
        db.session.commit()
        flash(f"You returned '{book.title}'.", "success")
    return redirect(url_for('index'))

@app.route('/check', methods=['POST'])
def check():
    query = request.form['check_title'].strip()
    if not query:
        flash("Please enter a book title to check.", "error")
        return redirect(url_for('index'))

    book = Book.query.filter(Book.title.ilike(f"%{query}%")).first()
    if not book:
        flash(f"No book found with title '{query}'.", "info")
    else:
        status = "Available" if book.available else "Borrowed"
        flash(f"'{book.title}' by {book.author} is {status}.", "success")
    return redirect(url_for('index'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
